import $ from 'jquery';

// @ts-ignore
$.widget.bridge('uiTooltip', $.ui.tooltip);
