User Guide
==========

.. toctree::
    :maxdepth: 2

    settings
    two_factor
    transformations
    bookmarks
    privileges
    relations
    charts
    import_export
    themes
    other
